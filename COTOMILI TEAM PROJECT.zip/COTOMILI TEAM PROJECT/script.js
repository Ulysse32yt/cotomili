function popup(id) {
    // Get the modal
    var modal = document.getElementById("myModal");
    var modalImg = document.getElementById("img01");
    modal.style.display = "block";
    modalImg.src = "images/" + id + "2.png";
  
    // Get the <span> element that closes the modal
    var span = document.getElementsByTagName("span")[0];
  
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    };
  }